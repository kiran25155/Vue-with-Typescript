<template>

  <router-view/>
 

</template>
<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name:'App',
 

  data() {
    return{
    
    } 
  
  }
 
   
 
})
</script>

<style scoped>
h1{
  text-align: center;
}
</style>


