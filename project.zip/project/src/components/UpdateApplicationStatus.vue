<template>
<form>
<fieldset v-if="update" style="max-height:300px">
    <h3>Update Status</h3>
    <table v-if="update" style="max-height:300px;">
      <tr>
        <td>Update Status</td>
        <td><input type='text' v-model="UpdateApplication.Status" v-bind:style="Ustyle"/></td>
      </tr>
      <tr>
        <td></td>
        <td><button @click.prevent="updateStatus()" style="background-color:green; color:aliceblue">Update</button></td>
      </tr>
    </table>
  </fieldset>
  </form>
  <slot></slot>
<table id="tupdate" style="border-collapse:collapse">
    <thead style="background-color:bisque;height: 60px;">
              <tr  style='border: 1px solid black;'>
                <th style='border: 1px solid black;'>Applicant Name</th>
                <th style='border: 1px solid black;'>email</th>
                <th style='border: 1px solid black;'>Mobile Number</th>
                <th style='border: 1px solid black;'>Degree</th>
                <th style='border: 1px solid black;'>Gender</th>
                <th style='border: 1px solid black;'>Job Role</th>
                <th style='border: 1px solid black;'>Status</th>
                <th style='border: 1px solid black;'>Action</th>
              </tr>
            </thead>
            <tbody style='border: 1px solid black;'>
              <tr v-for="item in trackApplication" :key="id">
              <td style='border: 1px solid black;'>{{item.Name}}</td>
              <td  style='border: 1px solid black;'>{{item.email}}</td>
              <td :key="id" style='border: 1px solid black;'>{{item.MobileNum}}</td>
              <td  :key="id" style='border: 1px solid black;'>{{item.Degree}}</td>
              <td  :key="id" style='border: 1px solid black;'>{{item.gender}}</td>
              
              <td    style='border: 1px solid black;'>{{item.Title}}</td>
              <td style='border: 1px solid black;'  v-bind:style="[item.Status!='Reject'?item.Status!='Accept'?item.Status=='offer letter'?{color:'#52BE80'}:{color:'#eed202'}:{color:'blue'}:{color:'red'}]">{{item.Status}}</td>
              <td style='border: 1px solid black;'><button @click="editUpdate(item.id)" style="background-color:green; color:aliceblue">Update</button></td>
              </tr>

            </tbody>
    <tbody> 

    </tbody>
</table>
    
</template>
<script lang="ts">
import { defineComponent } from 'vue'
import axios from 'axios';
export default defineComponent({
    name:'UpdateApplicationStatus',
    data() {
        return{
          n:0,
          update:false,
            trackApplication:[],
        Ustyle:{
          color:''
        },
      UpdateApplication:{
      Name: '',
      MobileNum: '',
      email: '',
      Degree: '',
      gender: '',
      Title: '',
      Status:'',
      id: ''
            }
        }
    },
    methods:{
      
       async ApplicatesData(){
         let result:any=await axios.get(`http://localhost:3000/AppicantStatus`)
            this.trackApplication=result.data
          
        },
       
        async editUpdate(id:number){
          this.update=true;
       let result:any=await axios.get(`http://localhost:3000/AppicantStatus/`+id)
       this.UpdateApplication=result.data;
       this.n=id
        },
        async updateStatus(){
        this.update=false
          let result:any=await axios.put(`http://localhost:3000/AppicantStatus/`+this.n,{
        'Name':this.UpdateApplication.Name,
        'MobileNum':this.UpdateApplication.MobileNum,
        'email':this.UpdateApplication.email,
        'Degree':this.UpdateApplication.Degree,
        'gender':this.UpdateApplication.gender,
        'Title':this.UpdateApplication.Title,
        'Status':this.UpdateApplication.Status
        })
       
         this.ApplicatesData();
        }
    },
    beforeMount(){
       this.ApplicatesData();
      
       
    }
   
})
</script>
<style scoped>
table,fieldset{
 
  margin-left: auto;
  margin-right: auto;
  text-align: center;
  max-width: 100px;
}
button{
  min-width:80px;
  min-height: 30px;
}
</style>
