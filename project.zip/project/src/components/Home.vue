<template>

   <body>
    <div class="row">
 
<a href="/">Home</a>
<a href="about.html">About</a>
<a href="/reg" >Register</a>
<a href="/EmpForgottenPass">Contact</a>
<a href="">suggestion</a>

<router-link to='/login'>Login</router-link>
</div>
 <h1>Welcome To Amiti Technologies</h1>
   </body>
   
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
    name:'Home',
    
})
</script>
<style scoped>

    div.row{
    overflow:hidden;
    background:white;
    margin-top:-80px;
    height:60px;
   
    margin-right:10px;
   margin-left:-10px;
    width:1300px
    }
    div.row a{
      font-size: 20px;
    float:left;
    color:#B22222;
    text-align:center;
    text-decoration:none;
    padding:20px 20px;
    width:160px;
    /* font-size:14px; */
    text-transform:uppercase;
    font-weight:bold; 
    }
    div.row a:hover{
    background:	#00008B;
    color:white;
    }
    * {
      box-sizing: border-box;
    }
    h1{
     text-align: center;
    color:#ff8c00;
    margin-left: auto;
    margin-right: auto;
    margin-top: 100px;
    }
</style>
