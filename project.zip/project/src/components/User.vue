<template>
    <body>
<div class="row">
    <a @click.prevent="TrackApplication()" >Track My Application</a>
   <a @click.prevent="callNotification()">Notifications</a>
   
    <a @click="Logout" href="/login">Log Out</a>
</div>

  </body>

  <Notifications v-if="tsee"><h1 style="color:brown;text-align:center">Notifications</h1></Notifications>
  <TrackMyApplication style="text-align:center;" v-if="Tseen"><h1 style="color:brown">Track My Application</h1></TrackMyApplication>
  
</template>
<script lang="ts">
import { defineComponent } from 'vue'
import Notifications from './Notifications.vue';
import TrackMyApplication from './TrackMyApplication.vue';
export default defineComponent({
    name:'User',
    components:{ Notifications, TrackMyApplication},
    data() {
        return{
       tsee:false,
       Tseen:false
        }
      
    },
    methods:{
        callNotification(){
            this.tsee=true;
            this.Tseen=false;
        },
        TrackApplication(){
            this.tsee=false;
            this.Tseen=true;
        },
        Logout(){

      let email = localStorage.setItem('email', '')
      let pass = localStorage.setItem('pass', '')
        }
       
    },
   
   
   
    
    
})
</script>
<style scoped>
@import '../css/user.css'
</style>

