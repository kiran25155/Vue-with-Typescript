<template>
<body>
<div class="row">
 
<a href="/">Home</a>
<a href="about.html">About</a>
<a href="/reg" target="_self">Register</a>
<a href="forgottenPass.html">Contact</a>
<a href="">suggestion</a>

<router-link to='/login'>Login</router-link>
</div>

<h1>Welcome To Amiti Technologies</h1>

</body>
</template>
<script lang="ts">
import { defineComponent } from 'vue'
export default defineComponent({
name:'Welcome',

})
</script>
<style>
/* body{
background-image:url('~@/assets/company1.jpg');
background-repeat:no-repeat;
background-attachment:fixed;
background-size:cover;
} */
div.row{
overflow:hidden;
background:white;
margin-top:-80px;
height:70px;
text-align: left;
margin-right:10px;
margin-left:-1000px;
width:700px
}
div.row a{
float:left;
color:#B22222;
text-align:center;
text-decoration:none;
padding:20px 20px;
width:100px;
font-size:13px;
text-transform:uppercase;
font-weight:bold; 
}
div.row a:hover{
background:	#00008B;
color:white;
}
* {
  box-sizing: border-box;
}
h1{
 text-align: center;
color:orange;
margin-left: auto;
margin-right: 500px;
margin-top: 1000px;
}
</style>
