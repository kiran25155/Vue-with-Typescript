<template>
   <h1>Child Component</h1>
      <button  @click="userName(username)"> user Name</button>
</template>
<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
    name:'Parent',
    props:['userName'],
    data() {
        return{
          username:'Kiran'
          
        }
    }
  
    
})
</script>
