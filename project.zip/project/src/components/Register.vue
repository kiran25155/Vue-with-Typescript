<template>

    <body>
<div>
<fieldset style="background-color:white;border:2px solid red " class="reg">
<h1  style="text-align:center;color:#8B0000" >Register</h1>
<form  name="f1" @submit.prevent="validate()" >
<table class="reg" style="background-color:white" >

<tr>
<td>
Name:
</td>
<td>
<input type="text" placeholder="Name" v-model="Name" Id="Name"/><label style="color:red">*</label>

</td>
</tr>
<tr>
<td>
Mobile Number:
</td>
<td>
<input type="text" @change.prevent="mobInputs()"   placeholder="Mobile Number" v-model="MobileNum" Id="MobileNum"/><label style="color:red">*</label><br>
<label Id="invalid" v-if="seen" v-bind:style="color">{{Mvalid}}</label>
</td>
</tr>

<tr>
<td>
Email:
</td>
<td>
<input type="text" @change="emailInputs()" placeholder="email" v-model="email" Id="email"/><label style="color:red">*</label><br>
<label Id="invalid" v-if="Eseen" v-bind:style="Estyle">{{Evalid}}</label>
</td>
</tr>

<tr>
<td>
Date of Birth:
</td>
<td>
<input type="date" style="width:140px;font-size:15px ;scrollbar-highlight-color: #2916F5;" v-model="dob" Id="dob"/>  &emsp; &nbsp;&nbsp; &emsp;<label style="color:red">*</label>
</td>
</tr>
<tr>
<td>
Gender:
</td>
<td><label >
<input type="radio" name="gender" style="accent-color:#2916F5;height:17px; width:17px" v-model="picked" value="male"/>male
<input type="radio" name="gender" style="accent-color:#2916F5;height:17px; width:17px"  v-model="picked" Id="female" value="female"/>female  &emsp; &nbsp; &emsp;<label style="color:red">*</label>
</label>
</td>
</tr>

<tr>
<td>
Qualification:
</td>
<td>
<label ><input type="checkbox" style="accent-color:#2916F5;height:17px; width:17px" class="Degree" v-model="Degree" value="B.tech"/></label>B.tech
<input type="checkbox" class="Degree" style="accent-color:#2916F5;height:17px; width:17px" v-model="Degree"  value="BSc"/>Bsc
<input type="checkbox" class="Degree" style="accent-color:#2916F5;height:17px; width:17px" v-model="Degree"  value="MBA"/>MBA <label style="color:red">*</label>
</td>
</tr>
<tr>
<td>
Country:
</td>
<td>
  <div class="dropdown-content">
<select v-model="country" Id="country">
  
<option  value="select">select</option>
<option value="India">India</option>
<option value="Us">Us</option>
<option value="Cannada">Cannada</option>
<option value="Uk">Uk</option>
<option value="Austrila">Austrila</option>
<option value="Germany">Germany</option>
<option value="fernch">Fernch</option>

</select>
</div>
 &emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;
</td>
</tr>
<tr>
<td>
Create Password:
</td>
<td>
<input type="text" @change="passInputs()" v-model="password" Id="password"/><label style="color:red">*</label><br>
<label Id="invalid" v-if="Pseen" v-bind:style="Pstyle">{{Pvalid}}</label>

</td>
</tr>

<tr>
<td>
Confirm Password:
</td>
<td>
<input type="text" @change.prevent="cnfInputs" v-model="confirmpassword" Id="confpassword"/><label style="color:red">*</label><br>
<label Id="invalid" v-if="CPseen" v-bind:style="CPstyle">{{CPvalid}}</label>

</td>
</tr>

<tr>
<td>
Address:</td>
<td>
<textarea id="add" v-model="add" style="height:100px" row="6" cols="30"></textarea>

</td>
</tr>

<tr><td></td></tr>
<tr>
<!-- <td></td> -->
<td  colspan="2" >

<button  style="min-height: 50px; min-width: 380px;  background-color:#228B22;color:white">Register</button><br><br>

<router-link to="/" style="width=250px; height=50px; background-color:#228B22;color:white">back</router-link>
&nbsp;
<small style="color:#2916F5">if already registered</small><br> &emsp; &emsp; &emsp;

<a href="/login" style="color:#2916F5" target="_self">Log In</a>

</td></tr>
</table>
</form>
</fieldset>
</div>
</body>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import Register from '../Mixin/Register'
import Validation from '../Mixin/Validation'
export default defineComponent({

  name: 'Register',
  mixins:[
    Register,
    Validation
  ]


})
</script>
<style scoped>
@import '../css/Register.css';
</style>
