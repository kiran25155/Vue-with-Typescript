<template>
<body >
<div id="log">
<form>
 
  <div class="column">
      
<fieldset >
        <h3>Employee Login</h3>
<table class="t1">
<tr>
<td>Emp Id:</td>
<td><input type="text" @change.prevent="changInpts()" placeholder="Em****"  v-model="empId"/><br>
<label v-if="empid"  style="Estyle">{{Evalid}}</label></td></tr>
<tr>
<td>Password:<br/>
  <!-- <input type="checkbox" @change="Echeckbox" v-model="Echeck" style="background-color:yellow"/> -->
</td>
<td><input type="password" @change.="passInputs()" v-model="password"/><br>
<label v-if="crtpass"  style="Pstyle">{{Pvalid}}</label></td></tr>
<tr><td><button style="background-color:darkblue;width:60px; height:28px"><router-link to="/" style="text-decoration:none;color:white ">Back</router-link></button></td>
<td><button @click.prevent="checking()" style="background-color:darkblue;width:100px; height:30px; color:white">login</button></td></tr>
<tr>
<td></td>
<td style="text-align:right"><router-link to="/EmpForgottenPass" target="_self" >forgotten Password</router-link></td>
</tr>
</table>
</fieldset>

    </div>
    
    <div class="column">
<fieldset>
    <h3>User Login</h3>
<table>
<tr>
<td>Email:</td>
<td><input type="text"   v-model="email"/><br>
<label v-if="emailId"  style="Ustyle">{{Uvalid}}</label></td></tr>
<tr>
<td>Password:<br/>
  <!-- <input type="checkbox" @change="checkbox" v-model="check" style="background:yellow"/> -->
</td>

<td><input type="password"  v-model="pass"/><br>
<label v-if="UPpass"  style="UPstyle">{{UPvalid}}</label></td></tr>
<tr><td><button style="background-color:darkblue;;width:60px; height:28px"><router-link to="/" style="text-decoration:none;color:white ">Back</router-link>></button></td>
<td><button @click.prevent="userData()" style="background-color:darkblue;;width:100px; height:30px; color:white">login</button></td></tr>
<tr>
<td> </td>
<td style="text-align:right"><router-link to="/forgottenPass" target="_self" >forgotten Password</router-link></td>
</tr>
</table>
</fieldset>
</div>
</form>
</div>
</body>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import axios from 'axios';
export default defineComponent({
  name: 'LogIn',
  data () {
    return {
      Echeck:false,
      Etype:'password',
      check:false,
      type:'password',
      empId: '',
      empid: false,
      Estyle: {
        color: 'red'
      },
    
      Evalid: '',

      password: '',
      crtpass: false,
      Pstyle: {
        color: 'red'
      },
      Pvalid: '',

      email: '',
      emailId: false,
      Ustyle: {
        color: 'red'
      },
      Uvalid: '',

      pass: '',
      UPpass: false,
      UPstyle: {
        color: 'red'
      },
      UPvalid: ''
    }
  },
  methods: {

    changInpts: function () {
      let reg = /^Em\d{4}$/
      if (this.empId == '') {
        this.empid = true,
        this.Estyle.color = 'red',
        this.Evalid = 'Invalid'
      } else if (reg.test(this.empId)) {
        this.empid = true,
        this.Estyle.color = 'green',
        this.Evalid = 'valid'
      } else {
        this.empid = true,
        this.Estyle.color = 'red',
        this.Evalid = 'Invalid'
      }
    },
    passInputs () {
      let regExp = /^[A-Z](?=.*[!\@\#\$\%\^\&])(?=.*[a-z])(?=.*[0-9]).{7,}$/

      if (this.password == '') {
        this.crtpass = true,
        this.Pstyle.color = 'red',
        this.Pvalid = 'Invalid'
      } else if (regExp.test(this.password)) {
        this.crtpass = true,
        this.Pstyle.color = 'green',
        this.Pvalid = 'valid'
      } else {
        this.crtpass = true,
        this.Pstyle.color = 'red',
        this.Pvalid = 'Invalid'
      }
    },

    checking () {
      if ((this.empId == "Em1234") && (this.password == "Kiran@1234")) {
        window.location.href = '/Emp'
        alert('Sucessfully login')
      } else {
        alert('you details are not matched with our record')
      }
    },
    async userData() {
      
      let email = localStorage.setItem('email', this.email)
      let pass = localStorage.setItem('pass', this.pass)
      let results = await axios.get(
        `http://localhost:3000/ApplicateRecords?email=${this.email}&&password=${this.password}`
      );
      if(results.status==200){
        alert("sucessfully login");
        window.location.href='/user'
      }
      else{
        alert('you details are not matched with our record')
      }
    },
     checkbox(){
      if(this.check==true){
           this.type='text';
      }
      else{
        this.type='password';
      }
     },
     Echeckbox(){
      if(this.Echeck==true){
           this.Etype='text';
      }
      else{
        this.Etype='password';
      }

      
      // 
     }


  }
})
</script>

<style>
@import '../css/LogIn.css'


</style>
