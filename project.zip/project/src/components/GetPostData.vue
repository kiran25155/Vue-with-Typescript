<template>
    <body > 
       
        <fieldset id="postJob" v-if="Useen" style="text-align: center;"> 
        <h1 id="postTitile" style="color: #00008B;">Update Post</h1><br/>
        <form> 
<table id="postJobs"  v-if="Useen" style="max-height:150px">
    <tr >
        <td>
           <h4> Job Title:</h4>
        </td>
        <td >
            <input type="text" v-model="EditPost.Title">
        </td>
    </tr>
    <tr>
       <td ><h4>Description:</h4></td> 
       <td>
        <textarea v-model="EditPost.Description" style="height:100px" row="8" cols="20"></textarea>
       </td>
    </tr>
    <tr>
        <td ></td>
        <td><button  @click.prevent="update()" id="post" style="width:170px; height:40px ; background-color:#05770d;color:#fbfaf7">Update</button></td>
    </tr>
</table>

</form>
</fieldset>
<br>
<slot></slot>
        <table id="updatePost" style="border:1px solid black;border-collapse: collapse;   ">
        <thead style="background-color:bisque; border:1px solid black;height:50px">
        <th style="border:1px solid black">SNo</th>
        <th style="border:1px solid black">Job Title</th>
        <th style="border:1px solid black">Description</th>
        <th style="border:1px solid black">Action</th>
        </thead>
        <tbody style="border:1px solid black">
            <tr v-for="item in JobData" :key="item.id" style="border:1px solid black">
             <td style="border:1px solid black">{{item.id}}</td>
             <td style="border:1px solid black">{{item.Title}}</td>
             <td style="border:1px solid black">{{item.Description}}</td> 
            <td style="border:1px solid black">
                
                <button @click="editPost(item.id)" style="background-color:khaki;">Update</button>&nbsp;
            <button @click="deletePost(item.id)" style="background-color:firebrick;color:white;">Delete</button></td>
            </tr>
        </tbody>
        
    </table>
    </body>
</template>
<script lang="ts">
import { defineComponent } from 'vue'
import axios from 'axios';

export default defineComponent({
    name:'GetPostData',
    data(){
        return{
            n:0,
           Useen:false,
       JobData:[],
       EditPost:{
        Title:'',
        Description:''
       },
       edit:{
        Title:'',
        Description:''
       }
    }
    },
    methods:{
        async getData(){
       let results:any=await axios.get(`http://localhost:3000/postJobs`);
          this.JobData=results.data;
     },
     async deletePost(id:number){
    let results:any=await axios.delete(`http://localhost:3000/postJobs/`+id);
        alert("Post deleted Sucessfully");
        this.getData();
   },
       async editPost(id:number){
        this.Useen=true
    let result:any=await axios.get(`http://localhost:3000/postJobs/`+id);
             this.EditPost=result.data;
            this.n=id;

},
async update(){
    
  let r:any=await axios.get(`http://localhost:3000/postJobs/`+this.n)
        this.edit=r.data;
       let result=await axios.put(`http://localhost:3000/postJobs/`+this.n,{
    'Title':this.edit.Title,
    'Description':this.EditPost.Description
  })
  console.log(result)
  alert("Post Updated sucessfully")
  this.getData()
  this.EditPost.Description=""
  this.EditPost.Title=''
  this.Useen=false
}
},
    beforeMount():void{
        this.getData()
      },
})
</script>
<style scoped>
#updatePost{
    margin-left: auto;
    margin-right: auto;
    min-width: 900px;
    text-align: center;
     max-height:10px;
}
fieldset{
   border-color: brown;
    padding: 10px;
    min-width: 400px;
    margin-left: auto;
    margin-right: auto;
    text-align: center;
   
}
table{
    font-size: 20px;
  margin-top:-10px;
  margin-left: auto;
  margin-right: auto;
  text-align: center;
  
  
}
button{
  min-width:80px;
  min-height: 30px;
}
textarea{
    font-size: 20px;
}
input{
    font-size:20px;
    width:150px;
}
</style>
