<template>
    <body>
        <div class="row1">
        <a @click=" createPost()">Send Post</a>
        <a @click=" updateStatus()" >Update Applicate Status</a>
        <a @click.prevent="GetData()">Update Post</a>
    <a href="/login">Log Out</a>
    </div> 
<br>
<send-post  :seen="bool"></send-post>
<UpdateApplicationStatus v-if="update"><h1 style="color:crimson;text-align:center">Update Applicate status</h1></UpdateApplicationStatus>
<GetPostData v-if="getdata"><h1 style="color:crimson;text-align:center">Update Post Details</h1></GetPostData>
 </body>
</template> 
<script lang="ts">

import UpdateApplicationStatus from './UpdateApplicationStatus.vue';
import { defineComponent } from 'vue'
import sendPost from './sendPost.vue';
import GetPostData from './GetPostData.vue';
export default defineComponent({
  components: { sendPost,GetPostData,UpdateApplicationStatus },
   name:'EmpDetails',
   data():any{
   return{
       update:false,
      bool:false,
      getdata:false
 }
},
    methods:{
        createPost():void{
          this.update=false,
          this.bool=true,
          this.getdata=false
        },
        GetData():void{
          this.update=false,
       this.getdata=true,
       this.bool=false
        },
        updateStatus():void{
         this.update=true,
       this.getdata=false,
       this.bool=false 
        }
     }  
})
</script>
<style scoped>
@import '../css/Emp.css'
</style>
