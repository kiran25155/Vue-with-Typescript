<template>
    <body>
        <slot></slot>
        <table id="AppStatus" style="border-collapse:collapse">
            <thead style="background-color:bisque;height:50px">
              <tr>
                <th style="border:1px solid black">Applicant Name</th>
                <th style="border:1px solid black">email</th>
                <th style="border:1px solid black">Mobile Number</th>
                <th style="border:1px solid black">Degree</th>
                <th style="border:1px solid black">Gender</th>
                <th style="border:1px solid black">Job Role</th>
                <th style="border:1px solid black">Status</th>
                <th style="border:1px solid black"> Action</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in trackApplication" :key="id">
              <td style="border:1px solid black">{{item.Name}}</td>
              <td style="border:1px solid black" >{{item.email}}</td>
              <td :key="id" style="border:1px solid black">{{item.MobileNum}}</td>
              <td  :key="id" style="border:1px solid black">{{item.Degree}}</td>
              <td  :key="id" style="border:1px solid black">{{item.gender}}</td>
              
              <td style="border:1px solid black">{{item.Title}}</td>
              <td style="border:1px solid black" v-bind:style="[item.Status!='Reject'?item.Status!='Accept'?item.Status=='offer letter'?{color:'#52BE80'}:{color:'#eed202'}:{color:'blue'}:{color:'red'}]">{{item.Status}}</td>
              <td style="border:1px solid black"><button @click="withDraw(item.id)" style="background-color:crimson;color:aliceblue">Withdraw</button></td>
              </tr>

            </tbody>
        </table>

    </body>
</template>
<script lang="ts">
import { defineComponent } from 'vue'
import axios from 'axios'

export default defineComponent({
    data() {
        return{
          
                trackApplication:[],
    Application:{
      Name: '',
      MobileNum: '',
      email: '',
      Degree: '',
      gender: '',
      Title: '',
      Status:'',
      id: ''
            }
        }
   
    },
    methods:{
        async TrackApplication(){
            
            
          let email:string|null=localStorage.getItem('email')
            let result:any=await axios.get(`http://localhost:3000/AppicantStatus?email=${email}`);
            this.trackApplication=result.data;
            console.log(this.trackApplication)
            

        },
        async  withDraw(id:number){
            let email:string|null=localStorage.getItem('email')
            let result:any=await axios.delete(`http://localhost:3000/AppicantStatus/`+id)
            alert("Application Withdrawn Sucessfully");
            this.TrackApplication();
}
    },
    beforeMount(){
        this.TrackApplication();
    }
})
</script>
<style>
#AppStatus{
    font-size: larger;
    margin-left: auto;
    text-align: center;
    margin-right: auto;
    min-width:600px;
     min-height: 80px;
    border: 1px solid black;
 }
 button{
    font-size: large;
    width:100px ;
    height:40px;
    
 }
 /* 
table,fieldset{
 
  margin-left: auto;
  margin-right: auto;
  text-align: center;
  max-width: 900px;
} */
</style>
