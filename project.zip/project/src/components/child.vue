<template>
    <h1>Child Comp</h1>
<h3 style="color:red">{{name}}</h3>

</template>
<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
    name:'child',
    props:['name'],
    data(){
        return{
        
        }
        
    }
})
</script>
