<template>
    <body>
        <fieldset id="postJob" v-if="seen" style="text-align: center;"> 
        <h1 id="postTitile" style="color: #00008B;">Create Post</h1><br/>
        <form> 
<table id="postJobs"  v-if="seen">
    <tr >
        <td>
            <h4>Job Title:</h4>
        </td>
        <td >
           <input type="text" v-model="EditPost.Title">
        </td>
    </tr>
    <tr>
       <td ><h4>Description:</h4></td> 
       <td>
        <textarea v-model="EditPost.Description" style="height:100px" row="8" cols="20"></textarea>
       </td>
    </tr>
    <tr>
        <td ></td>
        <td><button  @click.prevent="posts()" id="post" style="width:200px; height:40px ; background-color:#05770d;color:#fbfaf7">post</button></td>
    </tr>
</table>

</form>
</fieldset>
 </body>

</template>
<script lang="ts">
import { defineComponent } from 'vue'
import axios from 'axios'

export default defineComponent({
    name:'SendPost',
     props: ['seen'],
    
    data() {
        return{
         EditPost:
        {
              Title:'',
            Description:''
        }
        }
    },
      
    methods:{
     async posts()
     {
       
     let result:any=await axios.post(`http://localhost:3000/postJobs`,{
    'Title':this.EditPost.Title,
    'Description':this.EditPost.Description
  })
  alert("Post Created Sucessfully")
  window.location.href='http://localhost:8081/Emp';
    }
    }
})
</script>
<style scoped>
fieldset{
    margin-top:60px;
    border-color: red;
    padding-block: 10px;
    padding-inline: 20px;
    min-width: 450px;
    margin-left: auto;
    margin-right: auto;
    text-align: center;
   
}
table{
    margin-top:-30px;

    font-size:large;
}
textarea{
    font-size: 20px;
}
input{
    width:180px;
}
button{
    width:100px;
}
</style>
