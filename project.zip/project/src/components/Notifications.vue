<template>
    <body>
        <slot></slot>
        <table  id="tNotification" style="border-collapse:collapse;border:1px solid black">
    <thead style="background-color:bisque;height:40px">
     <th style="border:1px solid black">SNo</th>
     <th style="border:1px solid black">Job Title</th>
     <th style="border:1px solid black">Description</th>
     <th style="border:1px solid black">Action</th>
    </thead>
    <tbody>
        <tr v-for="item in JobData" :key="item.id">
        <td style="border:1px solid black">{{item.id}}</td>
        <td style="border:1px solid black">{{item.Title}}</td>
        <td style="border:1px solid black">{{item.Description}}</td>
        <td style="border:1px solid black;color:blue"><a  @click="ApplyJob(item.id)">Apply</a></td></tr>

    </tbody>
</table>
    </body>
</template>
<script lang="ts">
import { defineComponent } from 'vue'
import axios from 'axios'
export default defineComponent({
    name:'Notifications',
  
    data() {
        return{
        JobData:[],
       job:{
        id:'',
        Title:'',
        Description:''
       },
       Status:'',
       ApplicantDatas: [
      {
        Name: '',
        MobileNum: '',
        email: '',
        dob: '',
        gender: '',
        Degree: '',
        country: '',
        password: '',
        confpassword: '',
        add: '',
        id: ''
      }
    ],
        ApplyDetails:{
        Name: '',
        MobileNum: '',
        email: '',
        dob: '',
        gender: '',
        Degree: '',
        country: '',
        password: '',
        confpassword: '',
        add: '',
        id: ''
      },
      get:[{
      Name: '',
      MobileNum: '',
      email: '',
      Degree: '',
      gender: '',
      Title: '',
      id: ''
      }],
      getDetails:{
      Name: '',
      MobileNum: '',
      email: '',
      Degree: '',
      gender: '',
      Title: '',
      id: ''
      }
        }
    },
    methods:{
      
     async callNotification(){
     let result=await axios.get(`http://localhost:3000/postJobs`);
     this.JobData=result.data;
     },
     async ApplyJob(id:number){
         let title:string=''
        let result:any= await axios.get(`http://localhost:3000/postJobs/`+id);
        this.job=result.data;
        // console.log(this.job);
        console.log(this.job.Title)
        let email=localStorage.getItem('email')
        let userdata:any=await axios.get(`http://localhost:3000/ApplicateRecords?email=${email}`)
        this.ApplicantDatas=userdata.data;
        console.log( this.ApplicantDatas)
        for(let appDetails of this.ApplicantDatas){
          this.ApplyDetails=appDetails
          console.log(this.ApplyDetails.Name+'hi')
        }
        // console.log(this.ApplicantData)

    //    if(this.job.Title==){

    //    }
   let Apply:any=await axios.get(`http://localhost:3000/AppicantStatus?email=${email}`)
           this.get=Apply.data
           for(let getData of this.get){
            this.getDetails=getData
            title=this.getDetails.Title
            if(title==this.job.Title){
                break;
            }
           }
        if(title==this.job.Title){
            alert(" you are Already Applied for Position")
        }
        else{
         let ApplicantStatus:any=await axios.post(`http://localhost:3000/AppicantStatus`,{

        'Name':this.ApplyDetails.Name,
        'MobileNum': this.ApplyDetails.MobileNum,
        'email': this.ApplyDetails.email,
        'Degree': this.ApplyDetails.Degree,
        'gender': this.ApplyDetails.gender,
        'Title':this.job.Title,
        'Status':this.Status

    })
    alert("Sucessfully Applied")
        
        }    
 }
},
beforeMount(){
    this.callNotification();
}
})
</script>
<style scoped>
#tNotification{
    margin-left: auto;
    margin-right: auto;
    width:600px;
    font-size: large;
    min-height:200px;
    text-align: center;
     border: 1px solid black;
    border-collapse: collapse;
}

</style> 

