<template>
    <div>
    <h1 style="color:coral">Contact to admin</h1>
<a href="mailto:saik25515@gmail.com"><mark>saik25515@gmail.com</mark></a>

</div>
</template>
<script lang="ts">
import { defineComponent } from 'vue'
name:'EmpForgottenPass'
export default defineComponent({
    setup() {
        
    },
})
</script>
<style scoped>
div{
     text-align: center;   
        background-color: white;
        margin-top:-70px;
        margin-left:-10px;
        margin-bottom:-10px;
        margin-right: -5px;
        min-height: 655px;
    }
    h1{
        
        padding-top:200px;
    }
a:link{
   
color:red;
}
</style>