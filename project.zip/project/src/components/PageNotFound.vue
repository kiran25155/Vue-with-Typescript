<template>
<div>
    <h1 >Page Not Found</h1>

   </div> 
</template>
<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
    name:'PageNotFound',
    setup() {
        
    },
})
</script>
<style scoped>

    div{
       
        background-color: white;
        margin-top:-70px;
        margin-left:-10px;
        margin-bottom:-10px;
        margin-right: -5px;
        min-height: 655px;
    }
    h1{
        text-align: center;
        padding-top:30px;
    }
</style>