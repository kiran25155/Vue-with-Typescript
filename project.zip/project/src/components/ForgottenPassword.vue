<template>
    <body>
        <form>
            <fieldset>
                <h1 style="text-align:center"></h1>
                <label>Email Id</label><br/>
                <input type="Email" v-model="email"/><br/>
                <label>Create New Password</label><br/>
                <input type="text" v-model="newpass"/><br/>
                <label>Confirm Password</label><br/>
                <input type="text" v-model="confirmpass"/><br/><br/>
                 <button style="background-color:forestgreen;color:white" @click.prevent="ForgottenPass">Generate new Password </button>
            </fieldset>
        </form>
    </body>
</template>
<script lang="ts">
import axios from 'axios'
import { defineComponent } from 'vue'

export default defineComponent({
    name:'ForgottenPassword',
   data():any {
        return{
            email:'',
          newpass:'',
          confirmpass:'',
          userDetails:[],
          user:{
        Name: '',
        MobileNum: '',
        email: '',
        dob: '',
        gender: '',
        Degree: '',
        country: '',
        password: '',
        confpassword: '',
        add: '',
        id: ''
          }
        }
    },
    methods:{
            async ForgottenPass(){
           
                 let result:any=await axios.get(`http://localhost:3000/ApplicateRecords?email=${this.email}`)
                   this.userDetails=result.data;
                   for(let userdetails of this.userDetails){
                    this.user=userdetails
                   }
                   console.log(result.data)
                   if(this.email==this.user.email){
                    if(this.confirmpass==this.newpass){

                    
                    let r:any=await axios.put(`http://localhost:3000/ApplicateRecords/`+this.user.id,{
        'Name': this.user.Name,
        'MobileNum': this.user.MobileNum,
        'email': this.user.email,
        'dob': this.user.dob,
        'gender': this.user.gender,
        'Degree': this.user.Degree,
        'country': this.user.country,
        'password': this.newpass,
        'confpassword': this.confirmpass,
        'add': this.user.add,
        'id': this.user.id
                
                })
                alert("Sucessfully Updated password");
                window.location.href='/login'
                    }
                    else{
                        alert('your password and confirm password should be same')
                    }
                   }
                   else{
                    alert('please check your email Id ')
                   }
            }
    }   
             
    
})
</script>
<style scoped>
fieldset{
    font-size: 20px;
    background-color:white;
    width:400px;
   margin-top:80px;
    padding-top: 20px;
    padding-bottom: 20px;
    margin-right: auto;
    margin-left: auto;
}
button{
height:30px;
}
</style>
